# Restaurant Menu Application

Food Menu with Details

This is tech food company which displays food items with price
